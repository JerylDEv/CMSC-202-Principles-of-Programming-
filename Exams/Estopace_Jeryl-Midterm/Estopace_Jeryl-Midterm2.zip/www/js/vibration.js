// Note: the onLoad() and onDeviceReady() functions are in the html file

function vibrate() {
    // Vibrate for 3 seconds.
    navigator.vibrate([3000]);
}